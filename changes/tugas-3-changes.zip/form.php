<div class="card">
    <div class="card-body">
        <?php $is_edit = isset($row); ?>
        <form method="post" action="<?php echo $is_edit ? base_url('prodi/ubah/'.$row['prodi_id']) : base_url('prodi/tambah') ?>">
            <div class="mb-3">
                <label class="form-label">ID Prodi</label>
                <?php if ($is_edit): ?>
                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($row['prodi_id']) ?>" disabled>
                <?php else: ?>
                    <input type="text" name="prodi_id" class="form-control <?php echo form_error('prodi_id') ? 'is-invalid' : (set_value('prodi_id') !== null ? 'is-valid' : '') ?>" value="<?php echo set_value('prodi_id') ?>">
                    <?php if (form_error('prodi_id')): ?>
                        <div class="invalid-feedback"><?php echo form_error('prodi_id') ?></div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label class="form-label">Nama Program Studi</label>
                <input type="text" name="prodi_name" class="form-control <?php echo form_error('prodi_name') ? 'is-invalid' : (set_value('prodi_name') !== null ? 'is-valid' : '') ?>" value="<?php echo set_value('prodi_name', $is_edit ? $row['prodi_name'] : '') ?>">
                <?php if (form_error('prodi_name')): ?>
                    <div class="invalid-feedback"><?php echo form_error('prodi_name') ?></div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Fakultas</label>
                <select name="fakultas_id" class="form-select <?php echo form_error('fakultas_id') ? 'is-invalid' : (set_value('fakultas_id') !== null ? 'is-valid' : '') ?>">
                    <option value="">-- Pilih Fakultas --</option>
                    <?php foreach ($fakultas as $f): ?>
                        <?php $sel = set_value('fakultas_id', $is_edit ? $row['fakultas_id'] : '') == $f['fakultas_id'] ? 'selected' : '' ?>
                        <option value="<?php echo $f['fakultas_id'] ?>" <?php echo $sel ?>><?php echo htmlspecialchars($f['fakultas_name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <?php if (form_error('fakultas_id')): ?>
                    <div class="invalid-feedback"><?php echo form_error('fakultas_id') ?></div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Strata</label>
                <div>
                        <?php $current = set_value('prodi_strata', $is_edit ? $row['prodi_strata'] : '') ?>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="prodi_strata" id="strata_s1" value="S1" <?php echo $current=='S1' ? 'checked' : '' ?> />
                            <label class="form-check-label" for="strata_s1">S1</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="prodi_strata" id="strata_d3" value="D3" <?php echo $current=='D3' ? 'checked' : '' ?> />
                            <label class="form-check-label" for="strata_d3">D3</label>
                        </div>
                </div>
                    <?php if (form_error('prodi_strata')): ?>
                        <div class="text-danger small mt-1"><?php echo form_error('prodi_strata') ?></div>
                    <?php endif; ?>
            </div>

            <div class="mb-3">
                <button class="btn btn-primary">Simpan</button>
                <a href="<?php echo base_url('prodi') ?>" class="btn btn-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
