<div class="card">
    <div class="card-body">
        <?php $is_edit = isset($row); ?>
        <form method="post" action="<?php echo $is_edit ? base_url('fakultas/ubah/'.$row['fakultas_id']) : base_url('fakultas/tambah') ?>">
            <div class="mb-3">
                <label class="form-label">ID Fakultas</label>
                <?php if ($is_edit): ?>
                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($row['fakultas_id']) ?>" disabled>
                <?php else: ?>
                    <input type="text" name="fakultas_id" class="form-control <?php echo form_error('fakultas_id') ? 'is-invalid' : (set_value('fakultas_id') !== null ? 'is-valid' : '') ?>" value="<?php echo set_value('fakultas_id') ?>">
                    <?php if (form_error('fakultas_id')): ?>
                        <div class="invalid-feedback"><?php echo form_error('fakultas_id') ?></div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Nama Fakultas</label>
                <input type="text" name="fakultas_name" class="form-control <?php echo form_error('fakultas_name') ? 'is-invalid' : (set_value('fakultas_name') !== null ? 'is-valid' : '') ?>" value="<?php echo set_value('fakultas_name', $is_edit ? $row['fakultas_name'] : '') ?>">
                <?php if (form_error('fakultas_name')): ?>
                    <div class="invalid-feedback"><?php echo form_error('fakultas_name') ?></div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <button class="btn btn-primary">Simpan</button>
                <a href="<?php echo base_url('fakultas') ?>" class="btn btn-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
